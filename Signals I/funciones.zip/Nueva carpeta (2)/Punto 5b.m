t=linspace(-3,4,1000);
y= u(t+1)+2*u(t)-u(t-1)-u(t-2)-u(t-3);
plot(t,y,'b')
grid on %rejilla
xlabel('t')
ylabel('y(t)')