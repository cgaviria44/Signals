
t=linspace(-3,5,1000);
y=(ramp(t+1).*u(-t))+(rect(t-0.5))+2*(rect(t-1.5));
subplot(3,1,1);
plot(t,y)
x=y.*u(1-t);
subplot(3,1,2);
plot(t,x)
z=y.*(u(t)-u(t-1));
subplot(3,1,3);
plot(t,z)
grid on %rejilla
xlabel('t')
ylabel('y(t)')

t=linspace(-3,5,1000);
y=ramp(t+1).*u(-t)+rect(t-0.5)+2*(rect(t-1.5));
x=y.*u(1-t);
plot(t,x,'m')
grid on %rejilla
xlabel('t')
ylabel('x(t)')

t=linspace(-3,5,1000);
y=ramp(t+1).*u(-t)+rect(t-0.5)+2*(rect(t-1.5));
x=y.*(u(t)-u(t-1));
plot(t,x,'c')
grid on %rejilla
xlabel('t')
ylabel('x(t)')

