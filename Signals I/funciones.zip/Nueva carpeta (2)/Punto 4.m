n=linspace(-3,3,7);
y=(rampDT(-n))+(rampDT(n));
stem(n,y)
grid on %rejilla
xlabel('n')
ylabel('y(n)')

n=linspace(-3,3,7);
y=rampDT(n)+rampDT(-n);
x=y.*uDT(1-n);
stem(n,x,'r','*')
grid on %rejilla
xlabel('n')
ylabel('x(n)')

n=linspace(-3,3,7);
y=rampDT(n)+rampDT(-n);
x=y.*(uDT(n+2)-uDT(n));
stem(n,x,'b','d')
grid on %rejilla
xlabel('n')
ylabel('x(n)')
