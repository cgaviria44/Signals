t=linspace(-1,3,1000);
y=ramp(0.5*t).*u(-t+2);
plot(t,y,'--g')
grid on %rejilla
xlabel('t')
ylabel('y(t)')